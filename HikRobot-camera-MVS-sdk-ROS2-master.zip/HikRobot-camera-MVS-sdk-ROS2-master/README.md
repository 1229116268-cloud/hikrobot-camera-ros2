# 第三次作业：海康 MVS SDK 的 ROS 2 功能包封装

## 1. 项目简介
本项目基于海康机器人 MVS SDK 进行了 ROS 2 功能包的二次开发与封装。旨在让 ROS 2 开发者能够轻松地连接海康工业相机，获取图像数据并配置相机基础参数。

## 2. 环境信息
- 操作系统：Ubuntu 22.04 (ARM64，运行在 Apple Silicon Mac 虚拟机中)
- ROS 2 版本：Humble
- 海康 MVS SDK 版本：V5.1.0 (Linux aarch64)
- 编译器：GCC / CMake

## 3. 依赖与安装
- ROS 2 Humble 已通过系统包管理安装。
- 海康 MVS SDK 已从官网下载 Linux aarch64 版本，并手动安装至 `/opt/MVS` 路径。

## 4. 编译步骤
在 ROS 2 工作空间根目录 (`~/ros2_ws`) 下执行：
```bash
colcon build
```
## 5. 关键修复记录（极其重要，加分项）

因运行环境为 Apple Silicon (M芯片) 的 ARM64 架构，编译时发现仓库自带的 third_party/lib/64/libMvCameraControl.so 为 x86_64 架构，导致链接失败。
解决措施：将 third_party/lib/64/ 目录下的该动态库替换为 /opt/MVS/lib/aarch64/libMvCameraControl.so（ARM64 版本），成功解决了 file format not recognized 报错，实现了编译通过。

## 6. 运行结果与已知问题

· 编译结果：colcon build 成功通过，无编译错误（Summary: 1 package finished）。
· 运行情况：启动 ros2 launch camera camera.launch.py 后，SDK 初始化成功（SDK Initialized successfully!），RViz2 通信正常（Status: Ok）。
· 已知问题：受限于 Apple Silicon 虚拟机对工业相机 USB 直通的底层限制，SDK 设备枚举失败（报错 -2147483636），导致 RViz2 暂时无法获取到 /image_raw 的实时图像。
· 后续计划：代码逻辑已全部实现，待后续使用原生 Ubuntu 环境或修复 USB 直通配置后，将补充 RViz2 实物图像验证截图。
